const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const app = express();
const PORT = 3001;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static('public'));

// Путь к папке с проектами
const PROJECTS_DIR = path.join(__dirname, 'projects');

// Создаем папку projects, если её нет
if (!fs.existsSync(PROJECTS_DIR)) {
    fs.mkdirSync(PROJECTS_DIR);
}

// Получить список всех проектов
app.get('/api/projects', (req, res) => {
    try {
        const files = fs.readdirSync(PROJECTS_DIR);
        const projects = files
            .filter(file => file.endsWith('.json'))
            .map(file => {
                const filePath = path.join(PROJECTS_DIR, file);
                const stats = fs.statSync(filePath);
                const content = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                return {
                    id: file.replace('.json', ''),
                    name: content.name || file.replace('.json', ''),
                    description: content.description || '',
                    createdAt: stats.birthtime,
                    lastModified: stats.mtime,
                    fileSize: stats.size
                };
            })
            .sort((a, b) => b.lastModified - a.lastModified);
        
        res.json(projects);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Сохранить проект
app.post('/api/projects/save', (req, res) => {
    try {
        const { id, name, description, users, transactions } = req.body;
        
        // Генерируем ID если его нет
        const projectId = id || Date.now().toString();
        const fileName = `${projectId}.json`;
        const filePath = path.join(PROJECTS_DIR, fileName);
        
        // Данные для сохранения
        const projectData = {
            id: projectId,
            name: name || 'Без названия',
            description: description || '',
            lastModified: new Date().toISOString(),
            users: users || [],
            transactions: transactions || []
        };
        
        // Сохраняем в файл
        fs.writeFileSync(filePath, JSON.stringify(projectData, null, 2));
        
        res.json({ 
            success: true, 
            id: projectId,
            message: 'Проект успешно сохранен',
            path: filePath
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Загрузить проект
app.get('/api/projects/load/:id', (req, res) => {
    try {
        const projectId = req.params.id;
        const fileName = `${projectId}.json`;
        const filePath = path.join(PROJECTS_DIR, fileName);
        
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'Проект не найден' });
        }
        
        const projectData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        res.json(projectData);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Удалить проект
app.delete('/api/projects/delete/:id', (req, res) => {
    try {
        const projectId = req.params.id;
        const fileName = `${projectId}.json`;
        const filePath = path.join(PROJECTS_DIR, fileName);
        
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            res.json({ success: true, message: 'Проект удален' });
        } else {
            res.status(404).json({ error: 'Проект не найден' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Экспортировать проект в JSON
app.get('/api/projects/export/:id', (req, res) => {
    try {
        const projectId = req.params.id;
        const fileName = `${projectId}.json`;
        const filePath = path.join(PROJECTS_DIR, fileName);
        
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'Проект не найден' });
        }
        
        res.download(filePath, `project_${projectId}.json`);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Импортировать проект из JSON
app.post('/api/projects/import', (req, res) => {
    try {
        const projectData = req.body;
        
        if (!projectData.id) {
            projectData.id = Date.now().toString();
        }
        
        const fileName = `${projectData.id}.json`;
        const filePath = path.join(PROJECTS_DIR, fileName);
        
        projectData.lastModified = new Date().toISOString();
        
        fs.writeFileSync(filePath, JSON.stringify(projectData, null, 2));
        
        res.json({ 
            success: true, 
            id: projectData.id,
            message: 'Проект успешно импортирован'
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Получить статистику по проектам
app.get('/api/projects/stats', (req, res) => {
    try {
        const files = fs.readdirSync(PROJECTS_DIR);
        const stats = {
            totalProjects: files.filter(f => f.endsWith('.json')).length,
            totalSize: 0,
            lastProject: null
        };
        
        files.forEach(file => {
            if (file.endsWith('.json')) {
                const filePath = path.join(PROJECTS_DIR, file);
                const stat = fs.statSync(filePath);
                stats.totalSize += stat.size;
                
                if (!stats.lastProject || stat.mtime > stats.lastProject.modified) {
                    stats.lastProject = {
                        name: file.replace('.json', ''),
                        modified: stat.mtime
                    };
                }
            }
        });
        
        stats.totalSizeMB = (stats.totalSize / (1024 * 1024)).toFixed(2);
        res.json(stats);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`🚀 Сервер запущен на http://localhost:${PORT}`);
    console.log(`📁 Проекты сохраняются в: ${PROJECTS_DIR}`);
});